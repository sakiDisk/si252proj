# 生成离线数据集：每个样本包含一个排列的物品列表，且每个物品具有观测反馈（0或1）
def generate_data(n, m, true_mean):
    dataset = []
    for _ in range(n):
        # 随机生成一个排列的物品列表
        S_t = np.random.choice(m, m, replace=False)
        # 随机决定触发的物品
        triggered = np.random.choice(S_t)
        # 对触发的物品根据其满意度生成反馈
        feedback = np.random.rand(m) < true_mean[S_t]
        dataset.append((S_t, triggered, feedback))
    return dataset

# 计算 LCB
def compute_lcb(empirical_means, n, m, delta):
    LCB = empirical_means - np.sqrt((2 * np.log(4 * m * n / delta)) / m)
    return LCB

# 使用 Top-k 选择算法，选择前k个物品
def top_k_selection(LCB, k):
    return nlargest(k, range(len(LCB)), key=lambda x: LCB[x])

# Off-CMAB 算法实现
def off_cmab_algorithm(dataset, k, delta):
    n = len(dataset)
    m = len(dataset[0][0])  # 物品数量
    empirical_means = np.zeros(m)
    N_i = np.zeros(m)

    # 计算每个物品的经验均值
    for S_t, triggered, feedback in dataset:
        for i in S_t:
            N_i[i] += 1
            empirical_means[i] += feedback[i]
    empirical_means /= N_i  # 计算每个物品的经验均值
    # 计算每个物品的 LCB
    LCB = compute_lcb(empirical_means, n, m, delta)
    # 选择最优的 k 个物品
    selected_items = top_k_selection(LCB, k)
    return selected_items, LCB