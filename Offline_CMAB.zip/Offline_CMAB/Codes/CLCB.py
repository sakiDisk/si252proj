# Define the CLCB algorithm
class CLCB:
    def __init__(self, arms, delta, dataset):
        self.arms = arms  # Number of arms
        self.delta = delta  # Confidence bound parameter
        self.dataset = dataset  # Offline dataset
        self.N = np.zeros(arms)  # Count of how many times each arm was selected
        self.mu_hat = np.zeros(arms)  # Empirical means for each arm
        self.lcb = np.zeros(arms)  # Lower confidence bounds
        self.action_history = []  # To store selected actions for visualization
    def update_empirical_means(self, t):
        """Update the empirical mean for the arms in round t"""
        for i in range(self.arms):
            if i in self.dataset[t]['triggered_arms']:
                self.N[i] += 1
                self.mu_hat[i] = (self.mu_hat[i] * (self.N[i] - 1) + self.dataset[t]['outcomes'][i]) / self.N[i]
    def compute_lcb(self):
        """Compute the lower confidence bound (LCB) for each arm"""
        for i in range(self.arms):
            if self.N[i] > 0:
                self.lcb[i] = self.mu_hat[i] - np.sqrt(np.log(4 * self.arms * len(self.dataset) / self.delta) / (2 * self.N[i]))
            else:
                self.lcb[i] = -np.inf  # If an arm hasn't been selected, its LCB is negative infinity
    def select_action(self):
        """Select the best arm based on the LCBs"""
        return np.argmax(self.lcb)  # Select the arm with the maximum LCB
    
    def run(self):
        """Run the CLCB algorithm on the dataset"""
        for t in range(len(self.dataset)):
            self.update_empirical_means(t)  # Update empirical means for triggered arms in round t
            self.compute_lcb()  # Recompute LCBs based on the updated means
            action = self.select_action()  # Select the best action based on LCBs
            self.action_history.append(action)
        return self.action_history