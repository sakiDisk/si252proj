# 生成离线数据集：每个样本包含缓存状态、查询、反馈的成本
def generate_data(n, m, true_cost, true_probability):
    dataset = []
    for _ in range(n):
        # 随机生成缓存和查询
        M_t = np.random.choice(m, size=np.random.randint(1, m + 1), replace=False)
        q_t = np.random.choice(m)
        cost_t = true_cost[q_t] + np.random.normal(0, 0.1)  # 生成带有噪声的成本反馈
        dataset.append((M_t, q_t, cost_t))
    return dataset

# 计算 LCB
def compute_lcb(empirical_costs, n, m, delta):
    LCB = empirical_costs - np.sqrt((2 * np.log(4 * m * n / delta)) / n)
    return LCB

# 使用 Top-k 选择算法，选择前k个查询
def top_k_selection(LCB, k):
    return nlargest(k, range(len(LCB)), key=lambda x: LCB[x])

# CLCB-LLM-C 算法实现
def clcb_llm_c_algorithm(dataset, k, delta):
    n = len(dataset)
    m = len(dataset[0][0])  # 查询集大小
    empirical_costs = np.zeros(m)
    N_i = np.zeros(m)
    # 计算每个查询的经验成本
    for M_t, q_t, cost_t in dataset:
        N_i[q_t] += 1
        empirical_costs[q_t] += cost_t
    empirical_costs /= N_i  # 计算每个查询的经验成本
    # 计算每个查询的 LCB
    LCB = compute_lcb(empirical_costs, n, m, delta)
    # 选择最优的 k 个查询
    selected_queries = top_k_selection(LCB, k)
    return selected_queries, LCB