# 生成离线数据集：每个样本包含种子集、激活节点集合和节点反馈（0或1）
def generate_data(n, m, true_activation_prob, true_influence_spread):
    dataset = []
    for _ in range(n):
        # 随机生成一个种子集
        S_t = np.random.choice(m, size=np.random.randint(1, m + 1), replace=False)
        # 随机生成被激活的节点集合
        activated_nodes = np.random.choice(S_t, size=np.random.randint(1, len(S_t) + 1), replace=False)
        # 生成每个节点的反馈（0或1），1表示该节点被激活，0表示未激活
        feedback = np.random.rand(m) < true_activation_prob
        dataset.append((S_t, activated_nodes, feedback))
    return dataset
# 计算 LCB
def compute_lcb(empirical_influence_spread, n, m, delta):
    LCB = empirical_influence_spread - np.sqrt((2 * np.log(4 * m * n / delta)) / n)
    return LCB
# 使用 Top-k 选择算法，选择前k个节点
def top_k_selection(LCB, k):
    return nlargest(k, range(len(LCB)), key=lambda x: LCB[x])
# Social Influence Maximization 算法实现
def social_influence_maximization(dataset, k, delta):
    n = len(dataset)
    m = len(dataset[0][0])  # 节点数量
    empirical_influence_spread = np.zeros(m)
    N_i = np.zeros(m)
    # 计算每个节点的经验影响力传播
    for S_t, activated_nodes, feedback in dataset:
        for i in S_t:
            N_i[i] += 1
            empirical_influence_spread[i] += feedback[i]

    empirical_influence_spread /= N_i  # 计算每个节点的经验影响力传播
    # 计算每个节点的 LCB
    LCB = compute_lcb(empirical_influence_spread, n, m, delta)
    # 选择最优的 k 个节点作为种子集
    selected_nodes = top_k_selection(LCB, k)
    return selected_nodes, LCB